# MTC Food Service Android অ্যাপ

এটি Android Studio দিয়ে APK বানানোর জন্য একটি starter project। অ্যাপের ভেতরে খাবারের মেনু, কার্ট, নাম ও ঠিকানা ফর্ম এবং WhatsApp-এ অর্ডার পাঠানোর ব্যবস্থা আছে।

## গুরুত্বপূর্ণ
- নমুনা মেনু ও দাম দেওয়া আছে। প্রকাশের আগে আপনার প্রকৃত খাবার, দাম, ডেলিভারি চার্জ ও নীতিমালা বসান।
- WhatsApp অর্ডার নম্বর: `8801572911894` (বাংলাদেশের কান্ট্রি কোডসহ)।
- অ্যাপটি WhatsApp-এ অর্ডারের খসড়া খুলবে; গ্রাহককে WhatsApp-এ Send চাপতে হবে।
- এটি starter source project, আগে থেকে কম্পাইল করা APK নয়।

## APK তৈরি করার নিয়ম
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio-তে `MTC_Food_Service_Android` ফোল্ডারটি Open করুন।
3. Gradle sync সম্পন্ন হতে দিন; প্রয়োজনে Android SDK Platform 35 ইনস্টল করুন।
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** নির্বাচন করুন।
5. তৈরি APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ থাকবে।
6. নিজের Android ফোনে APK কপি করে ইনস্টল করুন। ফোনে অনুমতি চাইলে “Install unknown apps” অনুমতি দিতে হতে পারে।

## দ্রুত ওয়েব ডেমো
`app/src/main/assets/index.html` ফাইলটি Chrome-এ খুললেও মেনু ও কার্ট পরীক্ষা করা যাবে। WhatsApp অর্ডার পাঠাতে ইন্টারনেট ও WhatsApp প্রয়োজন।
